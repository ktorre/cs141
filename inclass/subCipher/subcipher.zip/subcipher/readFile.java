import java.util.Scanner;
import java.io.*;
public class readFile {
    public static void main( String[] args ) throws Exception {

	subCipher buffer = new subCipher( subCipher.loadKey( args[0] ), args[1], true );
	Scanner inFile = buffer.getData();

	while ( inFile.hasNext() || buffer.hasNext() ) {
	    if ( ! inFile.hasNext() )
		inFile = buffer.getData();
	    if ( inFile.hasNext() )
		System.out.println( inFile.nextLine() );
	    else
		System.out.println();
	}
	System.out.println();
	// Done

    }

}