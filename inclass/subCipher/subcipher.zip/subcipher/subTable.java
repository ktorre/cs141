public class subTable {

    private char[] table = new char[ 26 ];
    
    // Constructor(s)?
    public subTable( String S ) throws Exception {
	init( S );
    }
    
    public subTable( char[] L ) throws Exception {
	init( String.valueOf( L ) );
    }

    // Initializer
    private void init( String S ) throws Exception {
	String LS = S.toLowerCase();

	if ( S.length() != 26 ) 
	    throw new Exception( "subTableException: Invalid String Length" );

	for ( int i = 0; i < LS.length(); i++ ) 
	    table[ i ] = LS.charAt( i );
    }

    // getChar( char c )
    public char getChar( char c ) {
	boolean upperCase;

	if ( ! ( c >= 'A' && c <= 'Z' ) &&
	     ! ( c >= 'a' && c <= 'z' ) ) {
	    return c;
	}

	upperCase = ( c >= 'A' && c <= 'Z' );
	if ( upperCase )
	    return (char)( table[ c - 'A' ] - 32 );
	return table[ c - 'a' ];
    }

}