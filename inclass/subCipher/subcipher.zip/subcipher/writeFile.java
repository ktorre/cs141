public class writeFile {
    public static void main( String[] args ) throws Exception {
	subCipher outFile = new subCipher( subCipher.loadKey( args[0] ), "encrypted_message.asc", false );
	String[] msg = 
	    { "Now is the time for all good programmers\n",
	      "to consider learning their ABCs and 123s.  If they\n",
	      "don't, they're doomed to fail!\n\n" };
	for ( int i = 0; i < msg.length; i++ )
	    outFile.println( msg[ i ] );
	outFile.close();
    }
}