import java.util.Scanner;
import java.io.*;
public class subCipher {
    
    private subTable encoder;
    private subTable decoder;
    private String   buffer;
    private Scanner  fromFile;
    private PrintWriter  toFile;
    private boolean  readerMode = true;

    // Static Method!
    public static String loadKey( String fname ) throws IOException {
	Scanner inFile = new Scanner( new File( fname ) );
	String key = inFile.nextLine();
	inFile.close();
	return key;
    }

    public subCipher( String S, String filename, boolean mode ) throws Exception {
	readerMode = mode;
	if ( readerMode )
	    initReader( S, filename );
	else
	    initWriter( S, filename );
    }

    //////////////////////////////////////////////////////////////////////
    // Both Modes

    private subTable makeDecoderTable( subTable encoder ) throws Exception {
	char fromChar, toChar;
	char[] decodeString = new char[ 26 ];

	for ( int i = 0; i < 26; i++ ) {
	    fromChar = (char)( 'a' + i );
	    toChar   = encoder.getChar( fromChar );
	    decodeString[ toChar - 'a' ] = fromChar;
	}
	return new subTable( decodeString );
    }

    public void close() {
	if ( readerMode )
	    fromFile.close();
	else
	    toFile.close();
    }

    // End Both Modes
    //////////////////////////////////////////////////////////////////////
    
    //////////////////////////////////////////////////////////////////////
    // Reader Mode - Reads an Encrypted file, decrypts and passes content
    //               back to user.

    private void initReader( String S, String filename ) throws Exception {
	encoder = new subTable( S );
	decoder = makeDecoderTable( encoder );
	fromFile = new Scanner( new File( filename ) );
    }
    
    public boolean hasNext() throws Exception {
	if ( ! readerMode )
	    throw new Exception( "subCipherException: Can't call hasNext on encryption to file" );
	return fromFile.hasNext();
    }
    
    public Scanner getData() throws Exception {
	String encS = "";
	String decS = "";

	if ( ! readerMode ) 
	    throw new Exception( "subCipherException: Can't get data in write mode." );
	if ( ! fromFile.hasNext() ) 
	    return new Scanner( "" );
	encS = fromFile.nextLine();
	for ( int i = 0; i < encS.length(); i++ )
	    decS += decoder.getChar( encS.charAt( i ) );
	return new Scanner( decS );
    }

    // End Reader Mode
    //////////////////////////////////////////////////////////////////////

    //////////////////////////////////////////////////////////////////////
    // Writer Mode - Creates a file that encrypts each line prior to output

    private void initWriter( String S, String filename ) throws Exception {
	encoder = new subTable( S );
	decoder = makeDecoderTable( encoder );
	toFile = new PrintWriter( new FileWriter( filename, false ) );
    }

    public void print( String S ) throws Exception {
	if ( readerMode )
	    throw new Exception( "subCipherException: Can't print on input object." );
	for ( int i = 0; i < S.length(); i++ )
	    toFile.print( encoder.getChar( S.charAt( i ) ) );
    }

    public void println( String S ) throws Exception {
	if ( readerMode )
	    throw new Exception( "subCipherException: Can't print on input object." );
	print( S );
	toFile.println();
    }

    // End Writer Mode
    //////////////////////////////////////////////////////////////////////

}