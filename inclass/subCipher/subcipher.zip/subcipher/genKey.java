// Generate a random substitution key
import java.util.Random;
public class genKey {
    public static void main( String[] args ) {
	char[] list = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 
			'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };
	char[] key = new char[ 26 ];
	Random R = new Random();
	int i = 0;
	int x;

	while ( ! empty( list ) ) {
	    x = R.nextInt( 26 );
	    if ( list[ x ] != (char)0 ) {
		key[ i ] = list[ x ];
		i++;
		list[ x ] = (char)0;
	    }
	    //	    System.out.print( "  " + i );
	}
	System.out.println( String.valueOf( key ) );
    }
    
    public static boolean empty( char[] L ) {
	for ( int i = 0; i < L.length; i++ )
	    if ( L[ i ] != (char)0  ) return false;
	return true;
	
    }
}